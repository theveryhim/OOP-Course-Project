package Sample;

import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import org.json.simple.parser.ParseException;

import java.io.IOException;
import java.net.URL;

public class MainMenu extends Application {
    private static MainMenu mainMenu;
    private static Stage stage;
    @FXML
    private PasswordField newPassword;
    public TextField lives;

    public void getLives(){
        String lifeText=lives.getText();
        //PlayPage.getInstance().thelives=lives.getText();
    }
    @FXML
    void showPassword() {
        String passwordText=newPassword.getText();
    }
    public static MainMenu getInstance() {
        if (mainMenu == null) {
            mainMenu = new MainMenu();
        }
        return mainMenu;
    }

    public void start(Stage stage) throws Exception {
        MainMenu.stage = stage;
        stage.resizableProperty().setValue(false);
        stage.setTitle("Pacman");
        URL welcomeUrl = getClass().getResource("/Database/mainMenu.fxml");
        Parent root = FXMLLoader.load(welcomeUrl);
        Scene scene = new Scene(root);
        scene.getStylesheets().add(getClass().getResource("/Database/style.css").toExternalForm());
        stage.setScene(scene);
        stage.show();
    }

    public void play() throws Exception {
        URL accountUrl=getClass().getResource("/Database/askLife.fxml");
        Parent root = FXMLLoader.load(accountUrl);
        Scene scene=new Scene(root);
        scene.getStylesheets().add(getClass().getResource("/Database/style.css").toExternalForm());
        stage.setScene(scene);
        stage.show();
    }

    public void startGame() throws Exception {
        //PlayPage.getInstance().start(stage);
    }

    public void scoreBoard() throws Exception {
        ScoreBoard.getInstance().start(stage);
    }
    public void account() throws IOException {
        URL accountUrl=getClass().getResource("/Database/account.fxml");
        Parent root = FXMLLoader.load(accountUrl);
        Scene scene=new Scene(root);
        scene.getStylesheets().add(getClass().getResource("/Database/style.css").toExternalForm());
        stage.setScene(scene);
        stage.show();
    }
    public void logout() throws Exception {
        WelcomeMenu.getInstance().start(stage);
    }

    public void changePassword(MouseEvent mouseEvent) throws IOException, ParseException {
        URL accountUrl=getClass().getResource("/Database/changePassword.fxml");
        Parent root = FXMLLoader.load(accountUrl);
        Scene scene=new Scene(root);
        scene.getStylesheets().add(getClass().getResource("/Database/style.css").toExternalForm());
        stage.setScene(scene);
        stage.show();
    }

    public void deleteAccount(MouseEvent mouseEvent) throws Exception {
        User.getLoggedInUser().deleteUser();
        WelcomeMenu.getInstance().start(stage);
    }

    public void back(MouseEvent mouseEvent) throws Exception {
        MainMenu.getInstance().start(stage);
    }

    public void setTheNewPassword(MouseEvent mouseEvent) throws Exception {
        User.getUserByUsername(User.loggedInUser.getUsername()).changePassword(newPassword.getText());
        MainMenu.getInstance().start(stage);
    }
}
