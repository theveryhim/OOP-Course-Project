package Sample;

import java.io.*;
import java.util.HashMap;
import java.util.Map;


import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class User {
    private String username;
    private String password;
    private int bestScore;
    public static File folder = new File("C:\\Users\\Datis\\IdeaProjects\\untitled8\\src\\main\\resources\\Users\\User");
    public static User loggedInUser;

    public User(String usernameText, String passwordText, String nicknameText, String emailText, String securityQuestionText, String securityAnswerText) {
    }

    public static User getLoggedInUser() {
        return loggedInUser;
    }
    public static void setLoggedInUser(User loggedInUser) {
        User.loggedInUser = loggedInUser;
    }


    public User(String username, String password) {
        setUsername(username);
        setPassword(password);
        setBestScore(0);
        createUser(username, password);
    }

    public int getBestScore() {
        return bestScore;
    }

    public String getUsername() {
        return username;
    }

    public User(String username, String password, String bestScore) {
        setUsername(username);
        setPassword(password);
        setBestScore(Integer.parseInt(bestScore));
    }

    public void setBestScore(int bestScore) {
        this.bestScore = bestScore;
    }

    private void setPassword(String password) {
        this.password = password;
    }

    private void setUsername(String username) {
        this.username = username;
    }

    private void createUser(String fileName, String password) {
        JSONObject user = new JSONObject();
        user.put("username", fileName);
        user.put("password", password);
        user.put("bestScore", 0);
        String name = fileName + ".json";
        try {
            File myWriter = new File("C:\\Users\\Datis\\IdeaProjects\\untitled8\\src\\main\\resources\\Users\\User", name);
            BufferedWriter writer = new BufferedWriter(new FileWriter(myWriter.getAbsolutePath()));
            writer.write(user.toJSONString());
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void deleteUser(){
        String fileName = "C:\\Users\\Datis\\IdeaProjects\\untitled8\\src\\main\\resources\\Users\\User\\" + username + ".json";
        File user = new File(fileName);
        user.delete();
    }
    public static boolean alreadyExists(String username) {
        String fileName = "C:\\Users\\Datis\\IdeaProjects\\untitled8\\src\\main\\resources\\Users\\User\\" + username + ".json";
        File user = new File(fileName);
        return user.exists();
    }

    public static boolean isPasswordRight(String username, String password) throws IOException, ParseException {
        String fileName = "C:\\Users\\Datis\\IdeaProjects\\untitled8\\src\\main\\resources\\Users\\User\\" + username + ".json";
        JSONParser jsonParser = new JSONParser();
        FileReader reader = new FileReader(fileName);
        //Read JSON file
        Object obj = jsonParser.parse(reader);

        JSONObject user = (JSONObject) obj;
        return user.get("password").equals(password);
    }
    public void changePassword(String newPassword) throws IOException, ParseException {
        setPassword(newPassword);
        String fileName = "C:\\Users\\Datis\\IdeaProjects\\untitled8\\src\\main\\resources\\Users\\User\\" + username + ".json";
        JSONParser jsonParser = new JSONParser();
        FileReader reader = new FileReader(fileName);
        //Read JSON file
        Object obj = jsonParser.parse(reader);

        JSONObject user = (JSONObject) obj;
        user.put("password",newPassword);
        try {
            File myWriter = new File("C:\\Users\\Datis\\IdeaProjects\\untitled8\\src\\main\\resources\\Users\\User",username+".json");
            BufferedWriter writer = new BufferedWriter(new FileWriter(myWriter.getAbsolutePath()));
            writer.write(user.toJSONString());
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static ArrayList<User> readUsersFromJson(File folder) {
        ArrayList<User> results = new ArrayList<>();


        File[] files = new File("C:\\Users\\Datis\\IdeaProjects\\untitled8\\src\\main\\resources\\Users\\User").listFiles();
//If this pathname does not denote a directory, then listFiles() returns null.

        for (File file : files) {
            if (file.isFile()) {
                String fileName = "C:\\Users\\Datis\\IdeaProjects\\untitled8\\src\\main\\resources\\Users\\User\\" + file.getName();
                JSONParser jsonParser = new JSONParser();
                try {
                    FileReader reader = new FileReader(fileName);
                    Object obj = jsonParser.parse(reader);
                    JSONObject user = (JSONObject) obj;
                    User user1=new User((String) user.get("username"),(String) user.get("password"),String.valueOf(user.get("bestScore")));
                    results.add(user1);
                } catch (ParseException | IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return results;
    }

    public static User getUserByUsername(String username) {
        for (User user : readUsersFromJson(folder)) {
            if (user.username.equals(username))return user;
        }
        return null;
    }

}
