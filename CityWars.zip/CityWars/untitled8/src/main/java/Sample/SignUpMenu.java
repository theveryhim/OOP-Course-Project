package Sample;

import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent; // Add this import statement
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.net.URL;

public class SignUpMenu extends Application {
    private static SignUpMenu signUpMenu;
    private static Stage stage;

    @FXML
    private TextField username;
    @FXML
    private PasswordField password;
    @FXML
    private TextField nickname;
    @FXML
    private TextField email;
    @FXML
    private TextField securityQuestion;
    @FXML
    private TextField securityAnswer;

    public static SignUpMenu getInstance() {
        if (signUpMenu == null) {
            signUpMenu = new SignUpMenu();
        }
        return signUpMenu;
    }

    @Override
    public void start(Stage stage) throws Exception {
        SignUpMenu.stage = stage;
        stage.resizableProperty().setValue(false);
        stage.setTitle("Sign Up");

        URL signUpUrl = getClass().getResource("/Database/signUpPage.fxml");
        Parent root = FXMLLoader.load(signUpUrl);
        Scene scene = new Scene(root);
        scene.getStylesheets().add(getClass().getResource("/Database/style.css").toExternalForm());
        stage.setScene(scene);
        stage.show();
    }

    public void signUp(MouseEvent mouseEvent) {
        String usernameText = username.getText();
        String passwordText = password.getText();
        String nicknameText = nickname.getText();
        String emailText = email.getText();
        String securityQuestionText = securityQuestion.getText();
        String securityAnswerText = securityAnswer.getText();

        if (User.alreadyExists(usernameText)) {
            showAlert("This username already exists");
        } else if (passwordText.length() < 8) {
            showAlert("Password must be at least 8 characters long");
        } else {
            new User(usernameText, passwordText, nicknameText, emailText, securityQuestionText, securityAnswerText);
            showAlert("You signed up successfully");
        }
    }

    private void showAlert(String message) {
        Stage dialogStage = new Stage();
        dialogStage.initModality(Modality.APPLICATION_MODAL);

        VBox vbox = new VBox(new Text(message));
        vbox.setAlignment(Pos.CENTER);
        vbox.setPadding(new Insets(15));
        dialogStage.resizableProperty().setValue(false);
        dialogStage.setScene(new Scene(vbox));
        dialogStage.show();
    }

    public void back(MouseEvent mouseEvent) throws Exception {
        WelcomeMenu.getInstance().start(stage);
    }

    public void backToWelcome(MouseEvent mouseEvent) {
    }
}
