package Sample;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.net.URL;
import java.util.Timer;
import java.util.TimerTask;

public class WelcomeMenu extends Application {
    private static Stage stage;
    private static WelcomeMenu welcomeMenu;
    private int loginAttempts = 0;
    private boolean isLocked = false;

    @FXML
    private TextField username = new TextField();

    @FXML
    private PasswordField password = new PasswordField();

    @FXML
    void showMessage() {
        String usernameText = username.getText();
    }

    @FXML
    void showPassword() {
        String passwordText = password.getText();
    }

    public static WelcomeMenu getInstance() {
        if (welcomeMenu == null) {
            welcomeMenu = new WelcomeMenu();
        }
        return welcomeMenu;
    }

    @Override
    public void start(Stage stage) throws Exception {
        try {
            WelcomeMenu.stage = stage;
            stage.resizableProperty().setValue(false);
            stage.setTitle("Pacman");
            URL welcomeUrl = getClass().getResource("/Database/welcomePage.fxml");
            Parent root = FXMLLoader.load(welcomeUrl);
            Scene scene = new Scene(root);
            scene.getStylesheets().add(getClass().getResource("/Database/style.css").toExternalForm());
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }

    public void login(MouseEvent mouseEvent) throws Exception {
        if (isLocked) {
            showAlert("You are locked out. Please wait.");
            return;
        }

        if (!User.alreadyExists(username.getText())) {
            showAlert("This username doesn't exist");
        } else if (!User.isPasswordRight(username.getText(), password.getText())) {
            loginAttempts++;
            if (loginAttempts >= 2) {
                lockOut();
            } else {
                showAlert("Wrong Password!");
            }
        } else {
            loginAttempts = 0; // reset the attempts on successful login
            User.setLoggedInUser(User.getUserByUsername(username.getText()));
            MainMenu.getInstance().start(stage);
        }
    }

    private void lockOut() {
        isLocked = true;
        showAlert("Too many failed attempts. Please wait 10 seconds.");
        Timer timer = new Timer();
        TimerTask task = new TimerTask() {
            int countdown = 10;

            @Override
            public void run() {
                Platform.runLater(() -> {
                    if (countdown > 0) {
                        showAlert("Please wait " + countdown + " seconds.");
                        countdown--;
                    } else {
                        isLocked = false;
                        loginAttempts = 0;
                        showAlert("You can try logging in again.");
                        timer.cancel();
                    }
                });
            }
        };
        timer.scheduleAtFixedRate(task, 0, 1000);
    }

    private void showAlert(String message) {
        Stage dialogStage = new Stage();
        dialogStage.initModality(Modality.APPLICATION_MODAL);

        VBox vbox = new VBox(new Text(message));
        vbox.setAlignment(Pos.CENTER);
        vbox.setPadding(new Insets(15));
        dialogStage.resizableProperty().setValue(false);
        dialogStage.setScene(new Scene(vbox));
        dialogStage.show();
    }

    public void signUp(MouseEvent mouseEvent) throws Exception {
        SignUpMenu.getInstance().start(new Stage());
    }

    public void playAsGuest(MouseEvent mouseEvent) throws Exception {
        MainMenu.getInstance().start(stage);
    }

    public void exit(MouseEvent mouseEvent) {
        System.exit(0);
    }
}
