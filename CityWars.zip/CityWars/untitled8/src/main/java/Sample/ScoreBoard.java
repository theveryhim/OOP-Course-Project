package Sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.regex.Matcher;

public class ScoreBoard extends Application {
    private static Stage stage;
    public static ScoreBoard scoreBoard;

    public static ScoreBoard getInstance() {
        if (scoreBoard == null) scoreBoard = new ScoreBoard();
        return scoreBoard;
    }

    public GridPane father;
    public Label label;
    public void showScoreboard() {
        StringBuilder scoreBoard = new StringBuilder();
        int rank = 1,counter=0;
        ArrayList<String> sortWithArrayList = scoreboardShow();
        Collections.reverse(sortWithArrayList);

        for (int j = 0; j < sortWithArrayList.size(); ++j) {
            scoreBoard.append(rank + "-" + sortWithArrayList.get(j) + ":" + " " + User.getUserByUsername(sortWithArrayList.get(j))
                    .getBestScore() + "\n");
            if (j < sortWithArrayList.size() - 1 && User.getUserByUsername(sortWithArrayList.get(j)).getBestScore() !=
                    User.getUserByUsername(sortWithArrayList.get(j + 1)).getBestScore()){
                ++rank;
                rank+=counter;
                counter=0;
            }
            else if (j == sortWithArrayList.size() - 1 && User.getUserByUsername(sortWithArrayList.get(j)).getBestScore() !=
                    User.getUserByUsername(sortWithArrayList.get(j - 1)).getBestScore()){
                ++rank;
                rank+=counter;
                counter=0;
            }
            else ++counter;
        }
        label.setAlignment(Pos.BASELINE_CENTER);
        label.setText(scoreBoard.toString());
    }

    public static ArrayList<String> scoreboardShow() {
        ArrayList<User> scoreSorting = User.readUsersFromJson(User.folder);
        scoreSorting.sort(Comparator.comparing(User::getBestScore));
        ArrayList<String> scoreSortingUsernames = new ArrayList<>();
        for (User user : scoreSorting) {
            scoreSortingUsernames.add(user.getUsername());
        }
        return scoreSortingUsernames;
    }

    @Override
    public void start(Stage stage) throws Exception {
        ScoreBoard.stage = stage;
        stage.resizableProperty().setValue(false);
        stage.setTitle("Pacman");
        URL welcomeUrl = getClass().getResource("/Database/scoreBoard.fxml");
        Parent root = FXMLLoader.load(welcomeUrl);
        Scene scene = new Scene(root);
        scene.getStylesheets().add(getClass().getResource("/Database/style.css").toExternalForm());
        stage.setScene(scene);
        stage.show();

    }
    public void initialize(){
        showScoreboard();
    }

    public void back(MouseEvent mouseEvent) throws Exception {
        MainMenu.getInstance().start(stage);
    }
}
