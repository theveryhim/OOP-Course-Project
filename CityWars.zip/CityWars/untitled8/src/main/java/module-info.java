module Graphic {
    requires javafx.controls;
    requires javafx.fxml;
    requires json.simple;
    opens Sample to javafx.fxml;
    exports Sample;
}